#!/usr/bin/env bash
# Full First Access Pack gate battery — writes var/compliance/first_access_verify_report.json
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT"
OUT="${ROOT}/var/compliance/first_access_verify_report.json"
mkdir -p "$(dirname "$OUT")"

python3 - <<'PY'
import json
import os
import subprocess
import sys
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

root = Path.cwd()

def run(cmd, cwd=None):
    r = subprocess.run(cmd, cwd=cwd or root, capture_output=True, text=True)
    return r.returncode == 0, r.stdout.strip(), r.stderr.strip()

def file_ok(rel):
    p = root / rel
    return p.is_file(), p.stat().st_size if p.is_file() else 0

subsystems = {}

# Sync
ok, out, err = run(["make", "first-access-sync"])
subsystems["sync"] = {"gate_pass": ok, "detail": out.splitlines()[-1] if out else err}

# Inference
inf_script = root / "first_access_pack/02_terminal_vector/inference/run_local.sh"
ok, out, err = run(["bash", str(inf_script)])
throughput_path = root / "var/compliance/vis_throughput_report.json"
throughput = json.loads(throughput_path.read_text()) if throughput_path.is_file() else {}
subsystems["inference"] = {
    "gate_pass": ok and throughput.get("samples_per_sec", 0) > 0,
    "samples_per_sec": throughput.get("samples_per_sec"),
    "backend": throughput.get("backend"),
}

# RAG fidelity
rag_script = root / "first_access_pack/02_terminal_vector/proof_of_fidelity/run_proof_demo.sh"
ok, out, err = run(["bash", str(rag_script)])
rag_path = root / "var/compliance/rag_fidelity_report.json"
rag = json.loads(rag_path.read_text()) if rag_path.is_file() else {}
subsystems["rag_fidelity"] = {
    "gate_pass": ok and rag.get("gate_pass", False),
    "pass_count": rag.get("pass_count"),
    "fail_count": rag.get("fail_count"),
}

# PRISM CLI gate
prism_script = root / "first_access_pack/02_terminal_vector/prism_cli/run_prism_cli.sh"
ok, out, err = run(["bash", str(prism_script)])
prism_path = root / "var/compliance/prism_cli_gate_report.json"
prism = json.loads(prism_path.read_text()) if prism_path.is_file() else {}
subsystems["prism_cli"] = {
    "gate_pass": ok and prism.get("gate_pass", False),
    "repo": prism.get("repo"),
    "integrations": prism.get("integrations", []),
}

# Manifest paths
manifest_path = root / "CLRTY_SUBSTRATE/boot/first_access_manifest.json"
manifest = json.loads(manifest_path.read_text()) if manifest_path.is_file() else {}
required = [
    "first_access_pack/01_private_suite/manifest.json",
    "first_access_pack/02_terminal_vector/proof_of_fidelity/README.md",
    "first_access_pack/02_terminal_vector/inference/run_local.sh",
    "first_access_pack/02_terminal_vector/inference/bench_throughput.py",
    "first_access_pack/02_terminal_vector/alpha_api/KEY.template",
    "first_access_pack/02_terminal_vector/alpha_api/routes.md",
    "first_access_pack/02_terminal_vector/alpha_api/portal_link.json",
    "first_access_pack/02_terminal_vector/prism_cli/run_prism_cli.sh",
    "first_access_pack/02_terminal_vector/prism_cli/README.md",
    "first_access_pack/02_terminal_vector/proof_of_fidelity/sample_dataset/genesis_canonical.json",
    "first_access_pack/02_terminal_vector/proof_of_fidelity/sample_dataset/expected/valid_rag_report.json",
    "vis_intelligence/rag_verify.py",
    "vis_intelligence/inference_local.py",
    "frontend/investor/first-access-pack.html",
    "CLRTY_SUBSTRATE/bridge_perimeter/cross_chain_messaging.rs",
    "zk_guest/README.md",
]
missing = [p for p in required if not (root / p).is_file()]
routes = manifest.get("terminal_vector", {}).get("routes", [])
topology_route = "GET /v1/alpha/topology/logs" in routes
subsystems["manifest"] = {
    "gate_pass": len(missing) == 0 and topology_route and manifest_path.is_file(),
    "missing_paths": missing,
    "topology_route_registered": topology_route,
}

# Alpha API probe — use bearer when CLRTY_ALPHA_TOKEN set (localhost dev when unset)
alpha = {"gate_pass": True, "optional": True, "probed": False}
token = os.environ.get("CLRTY_ALPHA_TOKEN", "")
try:
    headers = {}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    req = urllib.request.Request(
        "http://127.0.0.1:8545/v1/alpha/topology/logs",
        headers=headers,
    )
    with urllib.request.urlopen(req, timeout=2) as resp:
        body = json.loads(resp.read().decode())
        alpha["probed"] = True
        alpha["gate_pass"] = resp.status == 200 and "isolation_threshold_ms" in body
        alpha["isolation_threshold_ms"] = body.get("isolation_threshold_ms")
        alpha["auth_mode"] = "bearer" if token else "localhost"
except Exception as e:
    detail = str(e)
    alpha["detail"] = detail
    if "401" in detail and token:
        alpha["hint"] = "Bearer rejected — check CLRTY_ALPHA_TOKEN matches clrty-api env"
    elif "401" in detail and not token:
        alpha["hint"] = "API requires bearer — export CLRTY_ALPHA_TOKEN or use localhost-only dev (unset token on server)"
    elif "Connection refused" in detail or "Errno 61" in detail:
        alpha["hint"] = "clrty-api not running — optional for gate_pass"
    alpha["gate_pass"] = True  # optional — not blocking if API not running
subsystems["alpha_api"] = alpha

blocking = ["sync", "inference", "rag_fidelity", "manifest", "prism_cli"]
gate_pass = all(subsystems[k]["gate_pass"] for k in blocking)

report = {
    "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    "gate_pass": gate_pass,
    "subsystems": subsystems,
}
out = root / "var/compliance/first_access_verify_report.json"
out.write_text(json.dumps(report, indent=2))
print(json.dumps(report, indent=2))
sys.exit(0 if gate_pass else 1)
PY
