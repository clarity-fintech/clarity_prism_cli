# Volkov Mastermind — First Access Pack

**Audience:** Elite technical networks · sovereign allocators · advanced searchers · liquid whales · researchers  
**Distribution:** **Exclusive** investor tier — not public marketing  
**Portal:** [`frontend/investor/first-access-pack.html`](../../frontend/investor/first-access-pack.html)

This pack is a **high-conviction deployment kit** — data primitives, terminal interfaces, and raw telemetry for architecture stress-testing **before** public launch.

---

## Distribution flow

```
                 ┌────────────────────────────────────────┐
                 │ VOLKOV MASTERMIND FIRST ACCESS PACK    │
                 └───────────────────┬────────────────────┘
                                     │
         ┌───────────────────────────┴───────────────────────────┐
         ▼                                                       ▼
┌────────────────────┐                                  ┌────────────────────┐
│ THE PRIVATE SUITE  │                                  │ THE TERMINAL VECTOR│
├────────────────────┤                                  ├────────────────────┤
│ • Tier 2 Tech Spec │                                  │ • Local MLX/PyTorch│
│ • Token Ecosystem  │                                  │   Inference Code   │
│ • Live Deck Link   │                                  │ • Closed Alpha API │
└────────────────────┘                                  └────────────────────┘
```

Machine-readable index: [`CLRTY_SUBSTRATE/boot/first_access_manifest.json`](../../CLRTY_SUBSTRATE/boot/first_access_manifest.json)

---

## I. The Private Suite

No fluff — primary artifacts for diligence and conviction.

| Asset | Path | What you get |
|-------|------|--------------|
| **Tier 2 Tech Spec** | [`TIER2_TECH_SPEC.md`](TIER2_TECH_SPEC.md) | Data primitives, repo anchors, verification commands |
| **Token ecosystem** | [`tokenomics_model.md`](tokenomics_model.md) | 16M cap, vesting, MIRRA, burn phases |
| **Technical DD** | [`technical_due_diligence.md`](technical_due_diligence.md) | MVM, PoC, MEV mitigation, dual-lock |
| **Security synthesis** | [`security_audit_report.md`](security_audit_report.md) | MSA-100 + Sovereign-600 |
| **Live deck (HUD)** | [`treasury-exclusive.html`](../../frontend/investor/treasury-exclusive.html) | Launch readiness · systemic zones |
| **MEV deep-dive** | `var/compliance/mev_deep_dive_report.json` | 16-suite math · topology · mitigation battery |

**Sync data:** `bash scripts/investor/build_first_access_data.sh`

---

## II. The Terminal Vector

Interfaces for operators who stress-test execution paths locally.

| Surface | Path | Role |
|---------|------|------|
| **Cognitive terminal** | [`cognitive-terminal.html`](../../frontend/investor/cognitive-terminal.html) | Moniverse calibration · inference HUD |
| **Treasury HUD** | [`treasury-dashboard.html`](../../frontend/investor/treasury-dashboard.html) | HELIX + NSD panels · quant skills |
| **VIS local inference** | [`vis_intelligence/`](../../vis_intelligence/) | PyTorch / MLX scaffold |
| **Closed Alpha API** | `clrty-api` `:8545` `/v1/alpha/*` | Raw JSON telemetry |

### Closed Alpha API (local)

```bash
cargo run -p clrty-api

curl -s http://127.0.0.1:8545/v1/alpha/manifest | jq .
curl -s http://127.0.0.1:8545/v1/alpha/telemetry | jq .
curl -s http://127.0.0.1:8545/v1/alpha/data-primitives | jq .

curl -s -X POST http://127.0.0.1:8545/v1/alpha/inference/score \
  -H 'Content-Type: application/json' \
  -d '{"spread_bps":400,"cancel_rate":0.5,"wallet_entropy":0.72}'
```

---

## III. Architecture integration (honest status)

Full plan: [`FIRST_ACCESS_ARCHITECTURE.md`](FIRST_ACCESS_ARCHITECTURE.md)

| Layer | Intent | Status |
|-------|--------|--------|
| **Local backend** | PyTorch + MLX on unified memory; weights decoupled from L1 | **Partial** — `vis_intelligence/` |
| **RAG verification** | Vector inputs verified against genesis before broadcast | **Partial** — `rag_verify.py` |
| **ZK / confidential** | RISC Zero / Zama wrap for pre-finalize verification | **Planned** |
| **Cross-chain messaging** | LayerZero / CCIP state settlement | **Deferred** — [`DEFERRED_BRIDGE.md`](../l1_launch/DEFERRED_BRIDGE.md) |

L1 authority remains **`clrty-1` / `uclrty`** only until Phase 10 bridge activation.

---

## Access

1. [`frontend/portal/gate.html`](../../frontend/portal/gate.html) → select **Exclusive**
2. Open **First Access** from investor nav
3. Run `make first-access-sync` before sessions with allocators

**Not on public site** — see [`DEFERRED_PUBLIC_WEBSITE.md`](../l1_launch/DEFERRED_PUBLIC_WEBSITE.md).
