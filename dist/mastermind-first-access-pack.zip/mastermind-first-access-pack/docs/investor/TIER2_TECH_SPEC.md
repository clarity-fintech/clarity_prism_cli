# Tier 2 Tech Spec — Data Primitives (First Access)

Concise index for masterminds and searchers. Full prose in linked docs.

---

## Supply & genesis (immutable)

| Primitive | Path | Verify |
|-----------|------|--------|
| Total supply 16M · null mint | `CLRTY_SUBSTRATE/boot/genesis_entropy.json` | `clrty chain genesis-verify` |
| Allocation checksum | `CLRTY_SUBSTRATE/boot/tokenomics_manifest.json` | `cargo test tokenomics_manifest_matches_genesis` |
| Denom | `uclrty` · chain `clrty-1` | genesis JSON |

---

## Consensus math

| Primitive | Formula / rule | Module |
|-----------|----------------|--------|
| PoC objective | `argmax(E − λR)` | `poc_consensus/mod.rs` |
| Set tiers | 100-tier binary index 99→1 | `entropy_sink_engine/set_dynamics/` |
| Topology gate | 50ms isolation | `token_core/blue_code/atmospheric_sync.rs` |

---

## Execution & MEV mitigation

| Primitive | Threshold / behavior | Module |
|-----------|----------------------|--------|
| Toxicity score | `spread_bps × 0.01 + cancel_rate` · flag > 5.0 | `arbitrage_core/toxicity/` |
| Slippage gate | Signal bridge `MAX_SLIPPAGE_BPS` | `clrty-signal-bridge` |
| HELIX netting | Internal match before public venue | `helix_engine/` |
| Dual-lock | One skill per account | `clrty-cli-core/skills/mod.rs` |
| Dead-man | 60s heartbeat → bridge pause | `arbitrage_core/dead_man.rs` |

**Battery:** `make mev-deep-dive` → `var/compliance/mev_deep_dive_report.json`

---

## Telemetry JSON (live sync)

| Artifact | Purpose |
|----------|---------|
| `var/pretest/systemic_readiness.json` | 100-task zones · L1 pulse |
| `var/trading/quant_skills_table.json` | MCA/TSR/AVR/EHL runtime |
| `var/trading/helix_runtime_table.json` | HELIX component status |
| `var/compliance/mev_deep_dive_report.json` | 16-suite MEV architecture test |
| `var/launch/mainnet_contract_gates.json` | Contract deployment gates |

Sync: `bash scripts/investor/build_first_access_data.sh`

---

## Closed Alpha API

Base: `http://127.0.0.1:8545/v1/alpha`

| Route | Returns |
|-------|---------|
| `GET /manifest` | Pack index |
| `GET /telemetry` | Readiness + MEV + HELIX snapshots |
| `GET /data-primitives` | File existence + byte sizes |
| `POST /inference/score` | Deterministic toxicity heuristic |

---

## Deep docs (Tier 1 reference)

- [`technical_due_diligence.md`](technical_due_diligence.md)
- [`helix_engine.md`](helix_engine.md)
- [`clarity_skills_overview.md`](clarity_skills_overview.md)
- [`docs/architecture/NEXUS_REPOSITORY.md`](../architecture/NEXUS_REPOSITORY.md)
