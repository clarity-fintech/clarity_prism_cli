# Computational Proof of Fidelity

Documents how CLRTY analyzes RAG outputs, **isolates hallucination**, and structures vector inputs before network broadcast.

## Algorithm (5 steps)

1. **Genesis anchor** — SHA-256 over canonical `genesis_entropy.json`; allocations must sum to 16M; `mint_authority` must be `null`.
2. **RAG output ingest** — Parse model/generation JSON claiming tokenomics or supply facts.
3. **Hallucination isolation** — Compare claimed fields vs canonical; emit reason codes:
   - `SUPPLY_INFLATION` — total_supply > 16_000_000
   - `MINT_AUTHORITY_SET` — mint_authority not null
   - `ALLOCATION_DRIFT` — bucket sum ≠ total_supply
   - `CHECKSUM_MISMATCH` — tokenomics checksum ≠ computed
4. **Vector structuring** — `feature_pipeline.py` → normalized feature vector with `wallet_entropy`, `toxicity_score`, `toxic_flow`.
5. **Broadcast gate** — Only if `rag_gate_pass: true` and `toxic_flow: false` (or queued via slippage gate).

## Sample dataset

See [`sample_dataset/`](sample_dataset/) — committed fixtures:

| File | Expected |
|------|----------|
| `rag_outputs/valid_allocation_summary.json` | PASS |
| `rag_outputs/hallucinated_supply.json` | FAIL · `SUPPLY_INFLATION` |
| `rag_outputs/drifted_mint_authority.json` | FAIL · `MINT_AUTHORITY_SET` |

## Run demo

```bash
./run_proof_demo.sh
# → var/compliance/rag_fidelity_report.json
```

**Implementation:** [`vis_intelligence/rag_verify.py`](../../../vis_intelligence/rag_verify.py)
