#!/usr/bin/env bash
# RAG proof-of-fidelity demo — runs sample_dataset fixtures via rag_verify.py
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../../.." && pwd)"
cd "$ROOT"

DATASET="${ROOT}/first_access_pack/02_terminal_vector/proof_of_fidelity/sample_dataset"
OUT="${ROOT}/var/compliance/rag_fidelity_report.json"

echo "== RAG proof-of-fidelity demo =="
python3 vis_intelligence/rag_verify.py --demo "$DATASET" --out "$OUT"
echo "Report: $OUT"
