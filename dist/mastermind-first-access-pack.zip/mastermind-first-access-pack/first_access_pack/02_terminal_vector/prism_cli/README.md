# PRISM CLI — First Access Terminal Vector

**Topic:** CLRTY PRISM intelligence CLI + visual terminal UI wired to blockchain integrations.

| Component | Path | Purpose |
|-----------|------|---------|
| Global CLI | `clarity-prism-cli/apps/cli` | `clrt` — PRISM · HELIX · Skills · pipeline |
| Terminal UI | `clarity-prism-cli/apps/prism-cli` | Visual PRISM menu · query backlog · live integrations |
| SDK | `clarity-prism-cli/packages/prism-*` | Intent engine · ledger · API clients |
| Repo | https://github.com/clarity-fintech/clarity_prism_cli | Standalone download ecosystem |

## Blockchain integrations (live when `CLRTY_API_URL` set)

| Integration | API route | Layer |
|-------------|-----------|-------|
| PRISM status | `GET /v1/prism/status` | Intelligence |
| Intent query | `POST /v1/prism/intent-aware` | Intelligence |
| HELIX kernel | `GET /v1/helix/status` | Shadow execution |
| L1 indexer | `GET /v1/indexer/clrty-l1` | Canonical chain |
| Settlement | `GET /v1/compliance/genesis-instructions` | Attested |
| Network intel | `GET /v1/intelligence/network` | Market snapshot |

Local fallback uses `var/ldnet/`, `var/helix/`, and browser mini-git ledger.

## Query backlog

- **Terminal UI:** type multiple prompts — one runs at a time, rest queue automatically.
- **CLI:** `clrt prism query "…"` serializes through shared queue; `clrt prism queue status` shows depth.

## Quick run (mastermind)

```bash
cd clarity-prism-cli
npm install
npm run build
bash npm-install-local.sh
node apps/cli/dist/index.js prism query "arbitrage opportunities"
npm run dev:terminal
```

## Mastermind gate

```bash
./first_access_pack/02_terminal_vector/prism_cli/run_prism_cli.sh
```
