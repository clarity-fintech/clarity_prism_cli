# Folder 02 — The Terminal Vector (Technical Execution)

Run, break, and verify CLRTY claims locally.

| Subfolder | Deliverable |
|-----------|-------------|
| [`prism_cli/`](prism_cli/README.md) | **PRISM CLI** · `clrt` · visual terminal · blockchain integrations · query backlog |
| [`inference/`](inference/README.md) | PyTorch + MLX configs · throughput bench |
| [`alpha_api/`](alpha_api/README.md) | Closed Alpha API · bearer key · topology logs |
| [`proof_of_fidelity/`](proof_of_fidelity/README.md) | RAG sample dataset · hallucination isolation |

## 15-minute stress path

```bash
# 0. PRISM CLI + blockchain integration gate
./first_access_pack/02_terminal_vector/prism_cli/run_prism_cli.sh

# 1. Local inference + throughput
./first_access_pack/02_terminal_vector/inference/run_local.sh

# 2. RAG proof-of-fidelity (all samples)
./first_access_pack/02_terminal_vector/proof_of_fidelity/run_proof_demo.sh

# 3. Alpha API (set key first — see alpha_api/KEY.template)
export CLRTY_ALPHA_TOKEN=your-issued-key
cargo run -p clrty-api
curl -s -H "Authorization: Bearer $CLRTY_ALPHA_TOKEN" \
  http://127.0.0.1:8545/v1/alpha/topology/logs | jq .

# 4. Full pack gate
make first-access-verify
```

Interactive portal: [`frontend/investor/first-access-pack.html`](../../frontend/investor/first-access-pack.html) · [`cognitive-terminal.html`](../../frontend/investor/cognitive-terminal.html)
