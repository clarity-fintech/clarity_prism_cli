# Closed Alpha API — Gateway & Interactive Key

Private access to real-time telemetry and topology logs. Pairs with the gated investor terminal.

**Base URL:** `http://127.0.0.1:8545/v1/alpha`  
**Implementation:** [`clrty-api/src/first_access.rs`](../../../clrty-api/src/first_access.rs)

## Interactive key

Copy [`KEY.template`](KEY.template) → `.env` (never commit):

```bash
export CLRTY_ALPHA_TOKEN=<issued-by-operator>
cargo run -p clrty-api
```

| Env state | Behavior |
|-----------|----------|
| `CLRTY_ALPHA_TOKEN` unset | Localhost-only (127.0.0.1) — dev mode |
| Token set | All `/v1/alpha/*` require `Authorization: Bearer <token>` |

## Routes

| Method | Path | Returns |
|--------|------|---------|
| GET | `/manifest` | Pack index JSON |
| GET | `/telemetry` | Readiness, MEV, HELIX, NSD snapshots |
| GET | `/data-primitives` | Primitive file metadata |
| GET | `/topology/logs` | Topology isolation events + zone pulse |
| POST | `/inference/score` | Toxicity score + MEV mitigation lane |

## Portal surfaces

| UI | Path |
|----|------|
| First Access Pack | [`frontend/investor/first-access-pack.html`](../../../frontend/investor/first-access-pack.html) |
| Cognitive terminal | [`frontend/investor/cognitive-terminal.html`](../../../frontend/investor/cognitive-terminal.html) |
| Gate (exclusive) | [`frontend/portal/gate.html`](../../../frontend/portal/gate.html) |

Machine-readable portal map: [`portal_link.json`](portal_link.json)
