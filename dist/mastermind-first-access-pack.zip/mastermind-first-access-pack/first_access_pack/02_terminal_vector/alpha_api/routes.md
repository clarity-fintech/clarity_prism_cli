# Closed Alpha API — curl examples

Base URL: `http://127.0.0.1:8545/v1/alpha`

Set your token (see `KEY.template`):

```bash
export CLRTY_ALPHA_TOKEN=your-secret
export AUTH="Authorization: Bearer $CLRTY_ALPHA_TOKEN"
```

## Routes

| Method | Path | Description |
|--------|------|-------------|
| GET | `/manifest` | First Access manifest |
| GET | `/telemetry` | Embedded compliance telemetry |
| GET | `/data-primitives` | File existence + byte counts |
| GET | `/topology/logs` | Topology isolation events + zone pulse |
| POST | `/inference/score` | Toxicity heuristic score |

## Examples

```bash
# Manifest
curl -s -H "$AUTH" http://127.0.0.1:8545/v1/alpha/manifest | jq .

# Telemetry
curl -s -H "$AUTH" http://127.0.0.1:8545/v1/alpha/telemetry | jq .

# Topology logs
curl -s -H "$AUTH" http://127.0.0.1:8545/v1/alpha/topology/logs | jq .

# Inference score
curl -s -X POST -H "$AUTH" -H "Content-Type: application/json" \
  -d '{"spread_bps":170,"cancel_rate":0.3,"wallet_entropy":0.5}' \
  http://127.0.0.1:8545/v1/alpha/inference/score | jq .
```

## Dev mode (no token)

When `CLRTY_ALPHA_TOKEN` is unset, only `127.0.0.1` requests are accepted.

```bash
curl -s http://127.0.0.1:8545/v1/alpha/telemetry | jq .
```
